#### import the simple module from the paraview
from paraview.simple import *
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

print("Start")
#****************************************************** Start Modified Part A***********************************************************************************
import os
import re
import csv
import sys
import operator
from shutil import copyfile


#Searching root directory

#for root,d_names,f_names in os.walk("."):
root=os.getcwd()

# *****************************************************Start: Paraview Part***************************************************************
if root == os.getcwd():
	print root

	i=1
	n=root
	path=n
	filename='dummy.foam'
	path=os.path.join(path,filename)
	#print(os.path.dirname("."))
	print("Processing data in: %s" %path)
	

	# create a new 'OpenFOAMReader'
	dummyfoam = OpenFOAMReader(FileName=os.path.abspath(path))

#****************************************************** End Modified Part A***********************************************************************************

	dummyfoam.MeshRegions = ['internalMesh']
	dummyfoam.CellArrays = ['U', 'k', 'nut', 'omega', 'p']

	# Properties modified on dummyfoam
	dummyfoam.LabelSize = '64-bit'
	dummyfoam.CellArrays = ['U']

	# get active view
	renderView1 = GetActiveViewOrCreate('RenderView')
	# uncomment following to set a specific view size
	renderView1.ViewSize = [1886, 1158]

	# show data in view
	dummyfoamDisplay = Show(dummyfoam, renderView1)
	# trace defaults for the display properties.
	dummyfoamDisplay.Representation = 'Surface'
	dummyfoamDisplay.ColorArrayName = [None, '']
	dummyfoamDisplay.OSPRayScaleArray = 'U'
	dummyfoamDisplay.OSPRayScaleFunction = 'PiecewiseFunction'
	dummyfoamDisplay.SelectOrientationVectors = 'U'
	dummyfoamDisplay.ScaleFactor = 2.056599998474121
	dummyfoamDisplay.SelectScaleArray = 'None'
	dummyfoamDisplay.GlyphType = 'Arrow'
	dummyfoamDisplay.GlyphTableIndexArray = 'None'
	dummyfoamDisplay.DataAxesGrid = 'GridAxesRepresentation'
	dummyfoamDisplay.PolarAxes = 'PolarAxesRepresentation'
	#dummyfoamDisplay.ScalarOpacityUnitDistance = 0.2725894988862848

	# reset view to fit data
	renderView1.ResetCamera()


	# update the view to ensure updated data information
	renderView1.Update()

	# get animation scene
	animationScene1 = GetAnimationScene()

	animationScene1.GoToLast()

	# create a new 'Slice'
	slice1 = Slice(Input=dummyfoam)
	slice1.SliceType = 'Plane'
	slice1.SliceOffsetValues = [0.0]

	# init the 'Plane' selected for 'SliceType'
	slice1.SliceType.Origin = [4.984600067138672, 0.3922998905181885, 4.0]

	# Properties modified on slice1.SliceType
	slice1.SliceType.Origin = [4.98460006713867, 0.392299890518188, 0.5]
	slice1.SliceType.Normal = [0.0, 0.0, 1.0]

	# Properties modified on slice1.SliceType
	slice1.SliceType.Origin = [4.98460006713867, 0.392299890518188, 0.5]
	slice1.SliceType.Normal = [0.0, 0.0, 1.0]

	# show data in view
	slice1Display = Show(slice1, renderView1)
	# trace defaults for the display properties.
	slice1Display.Representation = 'Surface'
	slice1Display.ColorArrayName = [None, '']
	slice1Display.OSPRayScaleArray = 'U'
	slice1Display.OSPRayScaleFunction = 'PiecewiseFunction'
	slice1Display.SelectOrientationVectors = 'U'
	slice1Display.ScaleFactor = 2.056599998474121
	slice1Display.SelectScaleArray = 'None'
	slice1Display.GlyphType = 'Arrow'
	slice1Display.GlyphTableIndexArray = 'None'
	slice1Display.DataAxesGrid = 'GridAxesRepresentation'
	slice1Display.PolarAxes = 'PolarAxesRepresentation'

	# hide data in view
	Hide(dummyfoam, renderView1)

	# update the view to ensure updated data information
	renderView1.Update()

	# set scalar coloring
	ColorBy(slice1Display, ('POINTS', 'U', 'Magnitude'))

	# rescale color and/or opacity maps used to include current data range
	slice1Display.RescaleTransferFunctionToDataRange(True, False)

	# show color bar/color legend
	slice1Display.SetScalarBarVisibility(renderView1, True)

	# get color transfer function/color map for 'U'
	uLUT = GetColorTransferFunction('U')
	uLUT.RGBPoints = [0.07823188785314428, 0.231373, 0.298039, 0.752941, 13.7619749037554, 0.865003, 0.865003, 0.865003, 27.445717919657653, 0.705882, 0.0156863, 0.14902]
	uLUT.ScalarRangeInitialized = 1.0

	#Reset Camera U_600
	# reset view to fit data bounds
	renderView1.ResetCamera(-0.291082710028, 1.75097799301, -0.349845141172, 0.332107722759, 0.0, 1.35144281387)


	# set active source
	SetActiveSource(dummyfoam)



#****************************************************** Start Modified Part B***********************************************************************************
	# create a new 'OpenFOAMReader'
	dummyfoam_1 =OpenFOAMReader(FileName=os.path.abspath(path))

#****************************************************** End Modified Part C***********************************************************************************

	# Properties modified on dummyfoam_1
	dummyfoam_1.LabelSize = '64-bit'
	dummyfoam_1.MeshRegions = ['motorBike_frt-fairing:001%1', 'motorBike_windshield:002%2', 'motorBike_rr-wh-rim:005%5', 'motorBike_rr-wh-rim:010%10', 'motorBike_fr-wh-rim:011%11', 'motorBike_fr-wh-brake-disk:012%12', 'motorBike_frame:016-shadow%13', 'motorBike_rear-susp:014%14', 'motorBike_rear-susp:014-shadow%15', 'motorBike_frame:016%16', 'motorBike_rr-wh-rim:005-shadow%17', 'motorBike_rr-wh-chain-hub:022%22', 'motorBike_rearseat%24', 'motorBike_frt-fairing%25', 'motorBike_windshield%26', 'motorBike_headlights%27', 'motorBike_driversseat%28', 'motorBike_rear-body%29', 'motorBike_fuel-tank%30', 'motorBike_exhaust%31', 'motorBike_rr-wh-rim%32', 'motorBike_fr-mud-guard%33', 'motorBike_fr-wh-rim%34', 'motorBike_fr-wh-brake-disk%35', 'motorBike_fr-brake-caliper%36', 'motorBike_fr-wh-tyre%37', 'motorBike_hbars%38', 'motorBike_fr-forks%39', 'motorBike_chain%40', 'motorBike_rr-wh-tyre%41', 'motorBike_square-dial%42', 'motorBike_round-dial%43', 'motorBike_dial-holder%44', 'motorBike_rear-susp%45', 'motorBike_rear-brake-lights%46', 'motorBike_rear-light-bracket%47', 'motorBike_frame%48', 'motorBike_rear-mud-guard%49', 'motorBike_rear-susp-spring-damp%50', 'motorBike_fairing-inner-plate%51', 'motorBike_clutch-housing%52', 'motorBike_radiator%53', 'motorBike_water-pipe%54', 'motorBike_water-pump%55', 'motorBike_engine%56', 'motorBike_rear-shock-link%57', 'motorBike_rear-brake-fluid-pot-bracket%58', 'motorBike_rear-brake-fluid-pot%59', 'motorBike_footpeg%60', 'motorBike_rr-wh-chain-hub%61', 'motorBike_rear-brake-caliper%62', 'motorBike_rider-helmet%65', 'motorBike_rider-visor%66', 'motorBike_rider-boots%67', 'motorBike_rider-gloves%68', 'motorBike_rider-body%69', 'motorBike_frame:0%70', 'motorBike_frt-fairing:001-shadow%74', 'motorBike_windshield-shadow%75', 'motorBike_fr-mud-guard-shadow%81', 'motorBike_fr-wh-brake-disk-shadow%83', 'motorBike_rear-mud-guard-shadow%84', 'motorBike_rear-susp-spring-damp-shadow%85', 'motorBike_radiator-shadow%86', 'motorBike_rear-shock-link-shadow%87', 'motorBike_rear-brake-fluid-pot-bracket-shadow%88', 'motorBike_rr-wh-chain-hub-shadow%89']
	#dummyfoam_1.CellArrays = ['U', 'p']
	dummyfoam_1.CellArrays = []


	# show data in view
	dummyfoam_1Display = Show(dummyfoam_1, renderView1)

	# trace defaults for the display properties.
	dummyfoam_1Display.Representation = 'Surface'
	dummyfoam_1Display.ColorArrayName = [None, '']
	dummyfoam_1Display.OSPRayScaleArray = 'CasePath'
	dummyfoam_1Display.OSPRayScaleFunction = 'PiecewiseFunction'
	dummyfoam_1Display.SelectOrientationVectors = 'None'
	dummyfoam_1Display.ScaleFactor = 0.20424311161041261
	dummyfoam_1Display.SelectScaleArray = 'None'
	dummyfoam_1Display.GlyphType = 'Arrow'
	dummyfoam_1Display.GlyphTableIndexArray = 'None'
	dummyfoam_1Display.DataAxesGrid = 'GridAxesRepresentation'
	dummyfoam_1Display.PolarAxes = 'PolarAxesRepresentation'

	# reset view to fit data
	#renderView1.ResetCamera()

#*************************************************************************************************************

	
	# update the view to ensure updated data information
	renderView1.Update()

	# Hide the scalar bar for this color map if no visible data is colored by it.
	#HideScalarBarIfNotNeeded(pLUT, renderView1)

	# set active source
	SetActiveSource(slice1)

	# Rescale transfer function
	uLUT.RescaleTransferFunction(0.07, 27.5)

	# get opacity transfer function/opacity map for 'U'
	uPWF = GetOpacityTransferFunction('U')
	uPWF.Points = [0.07823188785314428, 0.0, 0.5, 0.0, 27.445717919657653, 1.0, 0.5, 0.0]
	uPWF.ScalarRangeInitialized = 1

	# Rescale transfer function
	uPWF.RescaleTransferFunction(0.07, 27.5)



	# create a new 'Glyph'
	glyph1 = Glyph(Input=slice1,GlyphType='Arrow')
	glyph1.Scalars = ['POINTS', 'p']
	glyph1.Vectors = ['POINTS', 'U']
	glyph1.ScaleFactor = 0.25
	glyph1.GlyphTransform = 'Transform2'
	glyph1.MaximumNumberOfSamplePoints = 10000


	# get color transfer function/color map for 'GlyphScale'
	glyphScaleLUT = GetColorTransferFunction('GlyphScale')
	glyphScaleLUT.RGBPoints = [-77.85781860351562, 0.231373, 0.298039, 0.752941, 3.0425453186035156, 0.865003, 0.865003, 0.865003, 83.94290924072266, 0.705882, 0.0156863, 0.14902]
	glyphScaleLUT.ScalarRangeInitialized = 1.0

	# show data in view
	glyph1Display = Show(glyph1, renderView1)
	# trace defaults for the display properties.
	glyph1Display.Representation = 'Surface'
	glyph1Display.ColorArrayName = ['POINTS', 'GlyphScale']
	glyph1Display.LookupTable = glyphScaleLUT
	glyph1Display.OSPRayScaleArray = 'GlyphScale'
	glyph1Display.OSPRayScaleFunction = 'PiecewiseFunction'
	glyph1Display.SelectOrientationVectors = 'GlyphVector'
	glyph1Display.ScaleFactor = 2.1409821033477785
	glyph1Display.SelectScaleArray = 'GlyphScale'
	glyph1Display.GlyphType = 'Arrow'
	glyph1Display.GlyphTableIndexArray = 'GlyphScale'
	glyph1Display.DataAxesGrid = 'GridAxesRepresentation'
	glyph1Display.PolarAxes = 'PolarAxesRepresentation'

	# show color bar/color legend
	glyph1Display.SetScalarBarVisibility(renderView1, True)


	# set scalar coloring
	ColorBy(glyph1Display, ('POINTS', 'GlyphVector', 'Magnitude'))

	# Hide the scalar bar for this color map if no visible data is colored by it.
	HideScalarBarIfNotNeeded(glyphScaleLUT, renderView1)

	# rescale color and/or opacity maps used to include current data range
	glyph1Display.RescaleTransferFunctionToDataRange(True, False)

	# show color bar/color legend
	glyph1Display.SetScalarBarVisibility(renderView1, True)

	# get color transfer function/color map for 'GlyphVector'
	glyphVectorLUT = GetColorTransferFunction('GlyphVector')
	glyphVectorLUT.RGBPoints = [0.6294421181062961, 0.231373, 0.298039, 0.752941, 11.762529056546757, 0.865003, 0.865003, 0.865003, 22.89561599498722, 0.705882, 0.0156863, 0.14902]
	glyphVectorLUT.ScalarRangeInitialized = 1.0

	# hide color bar/color legend
	glyph1Display.SetScalarBarVisibility(renderView1, False)


	# update the view to ensure updated data information
	renderView1.Update()


	# set active source
	SetActiveSource(dummyfoam)

	#Reset Camera U_600
	# reset view to fit data bounds
	renderView1.ResetCamera(-0.291082710028, 1.75097799301, -0.349845141172, 0.332107722759, 0.0, 1.35144281387)

	# current camera placement for renderView1
	renderView1.CameraPosition = [-8.405171814983152, -10.53235842738578, 7.258080239613009]
	renderView1.CameraFocalPoint = [0.7299476414918905, -0.00886870920658104, 0.6757214069366453]
	renderView1.CameraViewUp = [0.2175790490432005, 0.37482192709970075, 0.9012035732190165]
	renderView1.CameraParallelScale = 1.2709710168500277

##############################################
	# set active source
	SetActiveSource(dummyfoam)
	# get color transfer function/color map for 'p'
	pLUT = GetColorTransferFunction('p')
	pLUT.RGBPoints = [-613.558654785156, 0.231373, 0.298039, 0.752941, -208.985641479492, 0.865003, 0.865003, 0.865003, 195.587371826172, 0.705882, 0.0156863, 0.14902]
	pLUT.ScalarRangeInitialized = 1.0

	# get active view
	renderView1 = GetActiveViewOrCreate('RenderView')
	# uncomment following to set a specific view size
	# renderView1.ViewSize = [1886, 1158]

	# show data in view
	dummyfoamDisplay = Show(dummyfoam, renderView1)
	# trace defaults for the display properties.
	dummyfoamDisplay.Representation = 'Surface'
	dummyfoamDisplay.ColorArrayName = ['POINTS', 'p']
	dummyfoamDisplay.LookupTable = pLUT
	dummyfoamDisplay.OSPRayScaleArray = 'p'
	dummyfoamDisplay.OSPRayScaleFunction = 'PiecewiseFunction'
	dummyfoamDisplay.SelectOrientationVectors = 'U'
	dummyfoamDisplay.ScaleFactor = 2.11617002487183
	dummyfoamDisplay.SelectScaleArray = 'p'
	dummyfoamDisplay.GlyphType = 'Arrow'
	dummyfoamDisplay.GlyphTableIndexArray = 'p'
	dummyfoamDisplay.DataAxesGrid = 'GridAxesRepresentation'
	dummyfoamDisplay.PolarAxes = 'PolarAxesRepresentation'
	#dummyfoamDisplay.ScalarOpacityFunction = pPWF
	dummyfoamDisplay.ScalarOpacityUnitDistance = 0.298408090320634

	# show color bar/color legend
	dummyfoamDisplay.SetScalarBarVisibility(renderView1, True)

	# change representation type
	dummyfoamDisplay.SetRepresentationType('Wireframe')

	# Hide the scalar bar for this color map if no visible data is colored by it.
	HideScalarBarIfNotNeeded(pLUT, renderView1)



	# current camera placement for renderView1
	renderView1.CameraPosition = [-3.4749726597947133, -5.5107245246660455, 5.941645686296516]
	renderView1.CameraFocalPoint = [0.72994764149189, -0.00886870920658112, 0.675721406936646]
	renderView1.CameraViewUp = [0.30984171645367, 0.52310292860921, 0.793953044471467]
	renderView1.CameraParallelScale = 1.27097101685003


#****************************************************** Start Modified Part C***********************************************************************************
	# save screenshot

	#SaveScreenshot(os.path.abspath('./U_500.jpg'), renderView1, ImageResolution=[1886, 1158])
	filename=os.path.basename(n)+'_.jpg'
	#filename='U_500_'+str(i)+'_.jpg'
	print('Saving Screenshot: '+filename)
	

	#Screenshot A
	ImagePath=os.path.join(n,filename)
	SaveScreenshot(os.path.abspath(ImagePath), renderView1, ImageResolution=[1886, 1158])

	#Screenshot B
	ImagePath=os.path.join(os.path.dirname(n),filename)
	SaveScreenshot(os.path.abspath(ImagePath), renderView1, ImageResolution=[1886, 1158])

	# destroy dummyfoams
	Delete(dummyfoam)
	del dummyfoam
	Delete(dummyfoam_1)
	del dummyfoam_1
	Delete(renderView1)
	del renderView1
	print('Iteration '+str(i)+' done')

#****************************************************** End Modified Part C***********************************************************************************


	#### uncomment the following to render all views
	# RenderAllViews()
	# alternatively, if you want to write images, you can use SaveScreenshot(...).
